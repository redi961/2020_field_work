﻿using Xamarin.Forms;

namespace Test.Cntrol
{
    public class CustomButton : Button
    {
        public CustomButton() : base()
        {
            const int animationTime = 50;

            Clicked += async (sender, e) =>
            {
                var btn = (CustomButton)sender;
                await btn.ScaleTo(0.8, animationTime, Easing.SinOut);
                await btn.ScaleTo(1, animationTime, Easing.SinIn);
            };
        }
    }
}

