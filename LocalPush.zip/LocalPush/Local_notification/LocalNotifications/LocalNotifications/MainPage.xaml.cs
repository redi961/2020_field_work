﻿using System;
using System.Diagnostics;
using Xamarin.Forms;

namespace LocalNotifications
{
    public partial class MainPage : ContentPage
    {
        INotificationManager notificationManager;
        int notificationNumber = 0;

        public MainPage()
        {
            InitializeComponent();

            notificationManager = DependencyService.Get<INotificationManager>();
            notificationManager.NotificationReceived += (sender, eventArgs) =>
            {
                var evtData = (NotificationEventArgs)eventArgs;
                ShowNotification(evtData.Title, evtData.Message);
            };
        }

        void OnSendClick(object sender, EventArgs e)
        {
           
            notificationNumber++;
            string title = $"로컬 알림 #{notificationNumber}";
            string message = $" {notificationNumber} 번째 알림입니다!";
            notificationManager.SendNotification(title, message);
        }

        void OnScheduleClick(object sender, EventArgs e)
        {
            notificationNumber++;
            string title = $"로컬 알림 #{notificationNumber}";
            string message = $" {notificationNumber} 번째 알림입니다!";
            notificationManager.SendNotification(title, message, DateTime.Now.AddSeconds(10));
        }

        void ShowNotification(string title, string message)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                var msg = new Label()
                {
                    Text = $"Notification Received:\nTitle: {title}\nMessage: {message}"
                };
                stackLayout.Children.Add(msg);
            });
        }
        private async void BtnMoveMy_Clicked(object sender, EventArgs e)
        {
            notificationNumber++;
            string title = $"로그인에 성공하였습니다!";
            string message = $"로그인에 성공하였습니다!";
            notificationManager.SendNotification(title, message);
            await Navigation.PushAsync(new Mypage());
        }

    }
}
