﻿using Xamarin.Forms;
using XamarinCustomControls.ViewModels;

namespace XamarinCustomControls
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            this.BindingContext = new VMMainPage();
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, true);
            this.Title = "Xamarin Custom Controls";
        }
    }
}
